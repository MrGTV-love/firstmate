# Recording-only resolved sibling verification before each Bash invocation.
if ! /usr/bin/cmp -s '/Users/charlesabrooker/.no-mistakes/worktrees/32d18ed9638d/01M4936GXM6ZTR79PNGMDJN2CH/.custody-live-validation/repo/bin/fm-remote-job-reap-orphans.sh' '/Users/charlesabrooker/.no-mistakes/worktrees/32d18ed9638d/01M4936GXM6ZTR79PNGMDJN2CH/.custody-live-validation/recorder.expected'; then
  printf 'SAFETY STOP: resolved sibling recorder differs\n' >&2
  exit 97
fi
printf 'verified pid=%s script=%s recorder_sha256=78beaebe525a5143c7cd54afdca74569f5b78917a680703787c127806f3f3ef4\n' "$$" "$0" >> '/Users/charlesabrooker/.no-mistakes/worktrees/32d18ed9638d/01M4936GXM6ZTR79PNGMDJN2CH/.custody-live-validation/recorder-verifications.log'

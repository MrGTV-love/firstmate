. "$FM_VALIDATION_VERIFY"
kill() {
  if [[ "$0" == */bin/fm-teardown.sh ]] && [[ "${1:-}" == -TERM || "${1:-}" == -KILL ]] && [ "$#" -eq 2 ]; then
    local observed_pid=$2 observed_signal=${1#-} observed_journal="$FM_STATE_OVERRIDE/task-x1.teardown-processes"
    cp "$observed_journal" "$FM_SIGNAL_OBSERVE_DIR/$observed_pid.$observed_signal.before-signal.audit" || return 96
    /bin/ps -ww -p "$observed_pid" -o pid=,lstart=,command= > "$FM_SIGNAL_OBSERVE_DIR/$observed_pid.$observed_signal.before-signal.ps" || return 96
    printf 'about to issue real %s to %s; durable audit snapshot captured\n' "$observed_signal" "$observed_pid" >> "$FM_SIGNAL_OBSERVE_DIR/signal-order.log"
  fi
  builtin kill "$@"
}

#!/usr/bin/env bash
# Behavior tests for the spawn-owned AI commit-trailer strip.
#
# Cursor injects Co-Authored-By after the typed message, so these cases assert
# the commit OBJECT, never the string passed to -m. The strip is the public
# interface; tests drive git commit through the installed hooksPath the same
# way a fleet-launched pane does.
set -u

# A fleet pane already carries GIT_CONFIG core.hooksPath. These cases set that
# override themselves, so drop the inherited one before any git command.
unset GIT_CONFIG_COUNT GIT_CONFIG_KEY_0 GIT_CONFIG_VALUE_0 GIT_CONFIG_PARAMETERS

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
# shellcheck source=tests/fixtures.sh
. "$(dirname "${BASH_SOURCE[0]}")/fixtures.sh"
# shellcheck source=bin/fm-backend.sh
. "$ROOT/bin/fm-backend.sh"

STRIP="$ROOT/bin/fm-git-strip-ai-trailers.sh"
TMP_ROOT=$(fm_test_tmproot fm-git-strip-ai-trailers)

fm_git_identity 'Captain Tests' 'captain@example.invalid'

with_hooks_env() {  # <hooks-dir> <command...>
  local hooks=$1
  shift
  GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=core.hooksPath GIT_CONFIG_VALUE_0=$hooks "$@"
}

make_repo() {
  local dir=$1
  fm_git_init_commit "$dir"
}

test_cursor_trailer_does_not_reach_the_commit_object() {
  local repo hooks body author
  repo="$TMP_ROOT/cursor-object"
  make_repo "$repo"
  hooks="$TMP_ROOT/hooks-cursor"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed on a real git repo"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: keep the typed message clean'
  body=$(git -C "$repo" log -1 --format=%B)
  author=$(git -C "$repo" log -1 --format='%an <%ae>')
  assert_not_contains "$body" "Co-authored-by: Cursor" "Cursor trailer reached the commit object"
  assert_not_contains "$body" "cursoragent@cursor.com" "Cursor email reached the commit object"
  assert_contains "$body" "fix: keep the typed message clean" "subject was rewritten"
  [ "$author" = "Captain Tests <captain@example.invalid>" ] || fail "author was rewritten: $author"
  pass "a Cursor --trailer commit object has no AI co-author and keeps the captain identity"
}


test_human_coauthor_is_kept() {
  local repo hooks body
  repo="$TMP_ROOT/human-coauthor"
  make_repo "$repo"
  hooks="$TMP_ROOT/hooks-human"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' --trailer 'Co-authored-by: Jane Doe <jane@example.com>' -m 'fix: mixed trailers'
  body=$(git -C "$repo" log -1 --format=%B)
  assert_not_contains "$body" "Cursor" "Cursor trailer was not stripped from a mixed message"
  assert_contains "$body" "Co-authored-by: Jane Doe <jane@example.com>" "human co-author was stripped"
  pass "a human Co-authored-by trailer survives next to a stripped Cursor trailer"
}

test_human_at_a_vendor_domain_is_kept() {
  local repo hooks body
  repo="$TMP_ROOT/vendor-human"
  make_repo "$repo"
  hooks="$TMP_ROOT/hooks-vendor-human"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q \
    --trailer 'Co-authored-by: Claude <noreply@anthropic.com>' \
    --trailer 'Co-authored-by: Jane Doe <jane@anthropic.com>' \
    --trailer 'Co-authored-by: Sam Roe <sam@cursor.com>' -m 'fix: vendor staff co-authors'
  body=$(git -C "$repo" log -1 --format=%B)
  assert_not_contains "$body" "noreply@anthropic.com" "the Claude bot trailer reached the commit object"
  assert_contains "$body" "Co-authored-by: Jane Doe <jane@anthropic.com>" "a human at a vendor domain was stripped"
  assert_contains "$body" "Co-authored-by: Sam Roe <sam@cursor.com>" "a human at a vendor domain was stripped"
  pass "a human co-author at a vendor domain survives; only the exact bot address is stripped"
}

test_hook_manager_cannot_displace_the_strip() {
  local repo hooks target body
  if [ "$(id -u)" = 0 ]; then
    pass "a hook manager cannot displace the strip (skipped as root)"
    return 0
  fi
  repo="$TMP_ROOT/hook-manager"
  make_repo "$repo"
  hooks="$TMP_ROOT/hooks-manager"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  target=$(with_hooks_env "$hooks" git -C "$repo" rev-parse --path-format=absolute --git-path hooks)
  [ "$target" = "$hooks" ] || fail "a hook manager in the pane would resolve $target, not the strip dir $hooks"
  mv "$target/commit-msg" "$target/commit-msg.old" 2>/dev/null &&
    fail "a hook manager could rename the strip's commit-msg aside"
  (printf '#!/bin/sh\nexit 0\n' >"$target/commit-msg") 2>/dev/null &&
    fail "a hook manager could overwrite the strip's commit-msg"
  (printf '#!/bin/sh\nexit 0\n' >"$target/post-update") 2>/dev/null &&
    fail "a hook manager could add a hook to the strip dir"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: after a manager tried'
  body=$(git -C "$repo" log -1 --format=%B)
  assert_not_contains "$body" "cursoragent@cursor.com" "Cursor trailer survived a hook manager's install attempt"
  pass "a hook manager resolving the pane hooks dir fails instead of displacing the strip"
}

test_reinstall_replaces_a_read_only_install() {
  local repo hooks body
  repo="$TMP_ROOT/reinstall"
  make_repo "$repo"
  hooks="$TMP_ROOT/hooks-reinstall"
  "$STRIP" install "$hooks" "$repo" || fail "first install should succeed"
  "$STRIP" install "$hooks" "$repo" || fail "a relaunch reinstall over the read-only install failed"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: after reinstall'
  body=$(git -C "$repo" log -1 --format=%B)
  assert_not_contains "$body" "cursoragent@cursor.com" "Cursor trailer survived after a reinstall"
  pass "a relaunch reinstall replaces the read-only strip dir and still strips"
}

test_previous_commit_msg_hook_still_runs() {
  local repo orig hooks
  repo="$TMP_ROOT/chain-hook"
  make_repo "$repo"
  orig=$(git -C "$repo" rev-parse --git-path hooks)
  case "$orig" in
  /*) ;;
  *) orig="$repo/$orig" ;;
  esac
  mkdir -p "$orig"
  cat >"$orig/commit-msg" <<'SH'
#!/usr/bin/env bash
printf 'ran\n' > "$(dirname "$1")/orig-commit-msg.ran"
exit 0
SH
  chmod 700 "$orig/commit-msg"
  hooks="$TMP_ROOT/hooks-chain"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: chain'
  [ -f "$repo/.git/orig-commit-msg.ran" ] || fail "the worktree's previous commit-msg hook did not run"
  assert_not_contains "$(git -C "$repo" log -1 --format=%B)" "Co-authored-by: Cursor" \
    "Cursor trailer survived even though the previous hook ran"
  pass "install chains the previous commit-msg hook after stripping"
}

write_marker_hook() {  # <path> <marker>
  cat >"$1" <<SH
#!/usr/bin/env bash
printf 'ran\n' > "\$PWD/$2.ran"
exit 0
SH
  chmod 700 "$1"
}

test_relative_project_hookspath_still_runs() {
  local repo hooks
  repo="$TMP_ROOT/husky-relative"
  make_repo "$repo"
  mkdir -p "$repo/.husky/_"
  write_marker_hook "$repo/.husky/_/pre-commit" husky-pre-commit
  git -C "$repo" config core.hooksPath .husky/_
  hooks="$TMP_ROOT/hooks-husky"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed with a relative core.hooksPath"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: husky relative'
  [ -f "$repo/husky-pre-commit.ran" ] || fail "the project's relative-hooksPath pre-commit hook did not run"
  assert_not_contains "$(git -C "$repo" log -1 --format=%B)" "Co-authored-by: Cursor" \
    "Cursor trailer survived a relative-hooksPath install"
  pass "a relative project core.hooksPath resolves against the worktree and still runs"
}

test_inherited_hookspath_env_does_not_decide_the_chain() {
  local repo hooks parent
  repo="$TMP_ROOT/nested-spawn"
  make_repo "$repo"
  write_marker_hook "$repo/.git/hooks/pre-commit" project-pre-commit
  parent="$TMP_ROOT/parent-hooks"
  mkdir -p "$parent"
  write_marker_hook "$parent/pre-commit" parent-pre-commit
  hooks="$TMP_ROOT/hooks-nested"
  with_hooks_env "$parent" "$STRIP" install "$hooks" "$repo" ||
    fail "install should succeed with an inherited GIT_CONFIG hooksPath"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q -m 'fix: nested spawn'
  [ -f "$repo/project-pre-commit.ran" ] || fail "the project's own pre-commit hook was not chained"
  [ -f "$repo/parent-pre-commit.ran" ] && fail "a parent spawn's hooks were chained into this worktree"
  pass "an inherited GIT_CONFIG hooksPath does not become the chained previous hooks"
}

test_project_hook_generated_after_install_still_runs() {
  local repo hooks
  repo="$TMP_ROOT/late-husky"
  make_repo "$repo"
  git -C "$repo" config core.hooksPath .husky/_
  hooks="$TMP_ROOT/hooks-late"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed before the project's hooks exist"
  mkdir -p "$repo/.husky/_"
  write_marker_hook "$repo/.husky/_/pre-commit" late-pre-commit
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  with_hooks_env "$hooks" git -C "$repo" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: late husky'
  [ -f "$repo/late-pre-commit.ran" ] || fail "a project hook generated after the spawn did not run"
  assert_not_contains "$(git -C "$repo" log -1 --format=%B)" "Co-authored-by: Cursor" \
    "Cursor trailer survived a late-generated project hooks directory"
  pass "a project hook that appears after install still runs for the rest of the task"
}

test_pane_hookspath_does_not_reroute_another_repository() {
  local repo other hooks
  repo="$TMP_ROOT/task-wt"
  other="$TMP_ROOT/other-repo"
  make_repo "$repo"
  make_repo "$other"
  write_marker_hook "$other/.git/hooks/pre-commit" other-pre-commit
  write_marker_hook "$repo/.git/hooks/pre-commit" task-pre-commit
  hooks="$TMP_ROOT/hooks-pane"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  printf 'note\n' >>"$other/README.md"
  git -C "$other" add README.md
  with_hooks_env "$hooks" git -C "$other" commit -q -m 'fix: other repo'
  [ -f "$other/other-pre-commit.ran" ] || fail "the other repository's own pre-commit hook did not run"
  [ -f "$other/task-pre-commit.ran" ] && fail "the task worktree's pre-commit ran inside another repository"
  [ -f "$repo/task-pre-commit.ran" ] && fail "the task worktree's pre-commit ran while committing elsewhere"
  pass "a pane GIT_CONFIG hooksPath still chains the repository git is actually in"
}

write_refusing_pre_push() {  # <path> <marker>
  cat >"$1" <<SH
#!/usr/bin/env bash
printf 'ran\n' >> "$2"
exit 1
SH
  chmod 700 "$1"
}

# A publish guard installed as the repository's pre-push must run however the
# pane's hooksPath reaches git: the pane export, git -c (GIT_CONFIG_PARAMETERS),
# or a child process that inherits either one.
test_repository_pre_push_runs_on_every_override_channel() {
  local repo remote hooks marker label child_push
  # shellcheck disable=SC2016 # the child shell expands its own positional args
  child_push='git -C "$1" push -q origin "HEAD:refs/heads/$2"'
  repo="$TMP_ROOT/guarded-push"
  remote="$TMP_ROOT/guarded-remote.git"
  make_repo "$repo"
  git init -q --bare "$remote"
  git -C "$repo" remote add origin "$remote"
  marker="$TMP_ROOT/guarded-push.pre-push"
  write_refusing_pre_push "$repo/.git/hooks/pre-push" "$marker"
  hooks="$TMP_ROOT/hooks-guarded"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  for label in env param env+param child-env child-param; do
    rm -f "$marker"
    case "$label" in
    env) with_hooks_env "$hooks" git -C "$repo" push -q origin "HEAD:refs/heads/$label" 2>/dev/null ;;
    param) git -C "$repo" -c core.hooksPath="$hooks" push -q origin "HEAD:refs/heads/$label" 2>/dev/null ;;
    env+param) with_hooks_env "$hooks" git -C "$repo" -c core.hooksPath="$hooks" push -q origin "HEAD:refs/heads/$label" 2>/dev/null ;;
    child-env) with_hooks_env "$hooks" sh -c "$child_push" _ "$repo" "$label" 2>/dev/null ;;
    child-param) git -C "$repo" -c core.hooksPath="$hooks" -c "alias.guarded-push=!git push -q origin HEAD:refs/heads/$label" guarded-push 2>/dev/null ;;
    esac && fail "push via $label succeeded past the repository's refusing pre-push hook"
    [ -f "$marker" ] || fail "the repository's pre-push hook did not run via $label"
    git -C "$remote" rev-parse -q --verify "refs/heads/$label" >/dev/null &&
      fail "push via $label reached the remote despite the refusing pre-push hook"
  done
  pass "the repository's pre-push runs and can refuse under every hooksPath override channel"
}

test_git_c_override_still_strips_and_chains_commit_hooks() {
  local repo hooks
  repo="$TMP_ROOT/param-commit"
  make_repo "$repo"
  write_marker_hook "$repo/.git/hooks/pre-commit" param-pre-commit
  hooks="$TMP_ROOT/hooks-param-commit"
  "$STRIP" install "$hooks" "$repo" || fail "install should succeed"
  printf 'note\n' >>"$repo/README.md"
  git -C "$repo" add README.md
  git -C "$repo" -c core.hooksPath="$hooks" commit -q --trailer 'Co-authored-by: Cursor <cursoragent@cursor.com>' -m 'fix: git -c override'
  [ -f "$repo/param-pre-commit.ran" ] || fail "the project's pre-commit hook did not run under git -c core.hooksPath"
  assert_not_contains "$(git -C "$repo" log -1 --format=%B)" "Co-authored-by: Cursor" \
    "Cursor trailer survived a git -c core.hooksPath commit"
  pass "a git -c hooksPath override still strips the trailer and chains the project's hooks"
}

test_strip_msgfile_alone_does_not_rewrite_author_fields() {
  local msg
  msg="$TMP_ROOT/msg.txt"
  printf '%s\n' 'fix: subject' '' 'Co-authored-by: Cursor <cursoragent@cursor.com>' >"$msg"
  "$STRIP" "$msg" || fail "strip should succeed"
  assert_not_contains "$(cat "$msg")" "Cursor" "strip left the Cursor trailer in the file"
  assert_contains "$(cat "$msg")" "fix: subject" "strip dropped the subject"
  pass "commit-msg file mode strips the trailer and keeps the subject"
}

# Use the real launch owner and a private tmux server. The omp replacement is
# a Git probe, not a model call: it exits immediately, leaving the SAME shell
# for the supported already-stopped-task relaunch path.
test_relaunch_reconciles_only_its_generated_hooks() {
  local ksh
  test_relaunch_reconciles_only_its_generated_hooks_in_shell bash /bin/bash
  ksh=$(command -v ksh) || {
    printf 'skip: ksh absent; ksh launch/relaunch hook transition not exercised\n'
    return
  }
  test_relaunch_reconciles_only_its_generated_hooks_in_shell ksh "$ksh"
}

test_relaunch_reconciles_only_its_generated_hooks_in_shell() {
  local shell_name="$1" shell_path="$2" shell_command
  local real_tmux dir home proj wt fakebin socket id hooks endpoint pane out scope n
  real_tmux=$(command -v tmux) || {
    printf 'skip: tmux absent; %s launch/relaunch hook transition not exercised\n' "$shell_name"
    return
  }
  dir="$TMP_ROOT/relaunch-$shell_name"
  mkdir -p "$dir"
  dir=$(cd "$dir" && pwd -P)
  home="$dir/home"
  proj="$dir/project"
  wt="$dir/wt"
  socket="$dir/tmux.sock"
  id="hooks-relaunch-$shell_name-$$"
  fakebin=$(fm_test_make_spawn_fakebin "$dir/fake")
  fm_test_spawn_home "$home" omp
  fm_test_spawn_brief "$home" "$id"
  fm_git_worktree "$proj" "$wt" fixture-hooks
  git -C "$wt" config core.hooksPath .project-hooks
  hooks="$home/state/$id.git-hooks"
  cat > "$fakebin/tmux" <<SH
#!/bin/sh
exec '$real_tmux' -S '$socket' "\$@"
SH
  cat > "$fakebin/omp" <<SH
#!/bin/sh
git config --show-scope --get-all core.hooksPath > '$dir/scope.tmp'
git config --get-all fixture.preserved > '$dir/preserved.tmp' || :
git config --show-scope --get fixture.operator > '$dir/operator.tmp' || :
mv '$dir/preserved.tmp' '$dir/preserved'
mv '$dir/operator.tmp' '$dir/operator'
mv '$dir/scope.tmp' '$dir/scope'
SH
  chmod +x "$fakebin/tmux" "$fakebin/omp"
  cat > "$dir/rc" <<SH
export PATH='$fakebin:$PATH'
treehouse() { if [ "\${1:-}" = get ]; then cd '$wt'; fi; }
PS1='fixture> '
SH
  case "$shell_name" in
    bash) shell_command="'$shell_path' --noprofile --rcfile '$dir/rc' -i" ;;
    ksh) shell_command="'$shell_path' -i" ;;
  esac
  # The socket and every terminal belong to this fixture; no shared tmux
  # environment, user shell startup file, or live worker is read or changed.
  env -i HOME="$home/user-home" PATH="$fakebin:$PATH" TERM=xterm ENV="$dir/rc" \
    GIT_CONFIG_GLOBAL="$GIT_CONFIG_GLOBAL" GIT_CONFIG_NOSYSTEM=1 \
    "$real_tmux" -S "$socket" -f /dev/null new-session -d -s firstmate \
    -c "$proj" "$shell_command" \
    || fail "cannot start owned $shell_name tmux fixture"
  "$real_tmux" -S "$socket" set-option -g default-command "$shell_command"
  trap '"$real_tmux" -S "$socket" kill-server 2>/dev/null || :; rm -rf "/tmp/fm-$id" "/tmp/fm-$id+"*; fm_test_cleanup' EXIT
  out=$(TMUX='' fm_test_run_spawn "$home" "$wt" "$fakebin" "$id" "$proj" \
    --mode no-mistakes --yolo off --harness omp --backend tmux)
  expect_code 0 "$?" "initial real tmux launch failed: $out"
  assert_present "$home/state/$id.meta" "initial launch did not publish a task record: $out"
  endpoint=$(fm_meta_get "$home/state/$id.meta" window)
  [ -n "$endpoint" ] || fail "initial launch recorded no endpoint: $out"
  pane=$("$real_tmux" -S "$socket" display-message -p -t "$endpoint" '#{pane_id}')
  for n in $(seq 1 100); do
    [ ! -f "$dir/scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/scope" ] || {
    "$real_tmux" -S "$socket" capture-pane -p -t "$endpoint" -S -100 >&2
    printf 'launch result: %s\n' "$out" >&2
    fail "initial launch never ran the Git probe"
  }
  scope=$(cat "$dir/scope")
  assert_contains "$scope" $'command\t'"$hooks" "initial launch did not select the strip layer"
  assert_contains "$scope" $'local\t.project-hooks' "repository hook config was changed"

  # Keep the generated entry between unrelated numbered entries, including
  # duplicate keys and values containing shell syntax that must remain data.
  "$real_tmux" -S "$socket" send-keys -t "$endpoint" \
    "export GIT_CONFIG_COUNT=4 GIT_CONFIG_KEY_0=fixture.preserved GIT_CONFIG_VALUE_0='first value' GIT_CONFIG_KEY_1=core.hooksPath GIT_CONFIG_VALUE_1='$hooks' GIT_CONFIG_KEY_2=fixture.preserved GIT_CONFIG_VALUE_2='literal \$(false); tail' GIT_CONFIG_KEY_3=fixture.operator GIT_CONFIG_VALUE_3=explicit" Enter
  : > "$home/config/keep-ai-trailers"
  rm "$dir/scope"
  out=$(TMUX='' fm_test_run_spawn "$home" "$wt" "$fakebin" "$id" --relaunch)
  expect_code 0 "$?" "same-task real tmux relaunch failed: $out"
  for n in $(seq 1 100); do
    [ ! -f "$dir/scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/scope" ] || fail "replacement launch never ran the Git probe"
  scope=$(cat "$dir/scope")
  assert_equals $'local\t.project-hooks' "$scope" \
    "keep-ai-trailers relaunch retained the obsolete command-scope strip override"
  assert_equals $'first value\nliteral $(false); tail' "$(cat "$dir/preserved")" \
    "relaunch lost or evaluated unrelated numbered Git configuration"
  assert_equals $'command\texplicit' "$(cat "$dir/operator")" \
    "relaunch lost explicit operator configuration"
  assert_equals "$endpoint" "$(fm_meta_get "$home/state/$id.meta" window)" "relaunch replaced the endpoint"
  assert_equals "$pane" "$("$real_tmux" -S "$socket" display-message -p -t "$endpoint" '#{pane_id}')" "relaunch replaced the pane"
  assert_equals "$wt" "$(fm_meta_get "$home/state/$id.meta" worktree)" "relaunch replaced the isolated copy"

  # An operator's hooksPath is not Firstmate's routing state, even if another
  # task's path has the same generated-looking suffix.
  "$real_tmux" -S "$socket" send-keys -t "$endpoint" \
    "export GIT_CONFIG_COUNT=2 GIT_CONFIG_KEY_0=core.hooksPath GIT_CONFIG_VALUE_0='$home/state/other.git-hooks' GIT_CONFIG_KEY_1=fixture.preserved GIT_CONFIG_VALUE_1=operator" Enter
  rm "$dir/scope"
  out=$(TMUX='' fm_test_run_spawn "$home" "$wt" "$fakebin" "$id" --relaunch)
  expect_code 0 "$?" "operator hooks relaunch failed: $out"
  for n in $(seq 1 100); do
    [ ! -f "$dir/scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/scope" ] || fail "operator relaunch never ran the Git probe"
  assert_contains "$(cat "$dir/scope")" $'command\t'"$home/state/other.git-hooks" \
    "relaunch removed an explicit operator hooksPath"

  # Turning stripping back on appends the task override without clobbering the
  # preserved operator entry. Repeating the launch must not accumulate entries.
  rm "$home/config/keep-ai-trailers"
  for n in 1 2; do
    rm "$dir/scope"
    out=$(TMUX='' fm_test_run_spawn "$home" "$wt" "$fakebin" "$id" --relaunch)
    expect_code 0 "$?" "strip-enabled relaunch $n failed: $out"
    local attempt
    for attempt in $(seq 1 100); do
      [ ! -f "$dir/scope" ] || break
      sleep 0.1
    done
    [ -f "$dir/scope" ] || fail "strip-enabled relaunch $n never ran the Git probe after $attempt polls"
    assert_equals "$(printf 'local\t.project-hooks\ncommand\t%s\ncommand\t%s' "$home/state/other.git-hooks" "$hooks")" \
      "$(cat "$dir/scope")" "strip launch lost operator routing or accumulated generated entries"
    assert_equals operator "$(cat "$dir/preserved")" "strip launch lost unrelated configuration"
  done
  : > "$home/config/keep-ai-trailers"
  : > "$home/config/launch-env-allowlist"
  rm "$dir/scope"
  out=$(TMUX='' fm_test_run_spawn "$home" "$wt" "$fakebin" "$id" --relaunch)
  expect_code 0 "$?" "allowlisted keep-ai-trailers relaunch failed: $out"
  for n in $(seq 1 100); do
    [ ! -f "$dir/scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/scope" ] || fail "allowlisted replacement never ran the Git probe"
  assert_equals $'local\t.project-hooks' "$(cat "$dir/scope")" \
    "allowlisted keep-ai-trailers worker selected a command-scope hook override"
  assert_equals '' "$(cat "$dir/preserved")" "allowlist leaked unrelated pane Git configuration"
  assert_equals "$endpoint" "$(fm_meta_get "$home/state/$id.meta" window)" "allowlisted relaunch replaced the endpoint"
  assert_equals "$pane" "$("$real_tmux" -S "$socket" display-message -p -t "$endpoint" '#{pane_id}')" "allowlisted relaunch replaced the pane"
  assert_equals "$wt" "$(fm_meta_get "$home/state/$id.meta" worktree)" "allowlisted relaunch replaced the isolated copy"
  "$real_tmux" -S "$socket" send-keys -t "$endpoint" \
    "git config --show-scope --get-all core.hooksPath > '$dir/pane-scope.tmp'; git config --get-all fixture.preserved > '$dir/pane-preserved'; env > '$dir/pane-env'; mv '$dir/pane-scope.tmp' '$dir/pane-scope'" Enter
  for n in $(seq 1 100); do
    [ ! -f "$dir/pane-scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/pane-scope" ] || fail "persistent pane never ran the Git probe"
  assert_equals "$(printf 'local\t.project-hooks\ncommand\t%s' "$home/state/other.git-hooks")" \
    "$(cat "$dir/pane-scope")" "persistent pane retained obsolete hooks or lost operator routing"
  assert_equals operator "$(cat "$dir/pane-preserved")" "persistent pane lost unrelated Git configuration"
  assert_contains "$(cat "$dir/pane-env")" 'GIT_CONFIG_COUNT=2' "persistent pane did not compact Git configuration"
  assert_not_contains "$(cat "$dir/pane-env")" "$hooks" "persistent pane still exports obsolete task hooks"

  rm "$home/config/keep-ai-trailers" "$dir/scope"
  out=$(TMUX='' fm_test_run_spawn "$home" "$wt" "$fakebin" "$id" --relaunch)
  expect_code 0 "$?" "allowlisted strip-enabled relaunch failed: $out"
  for n in $(seq 1 100); do
    [ ! -f "$dir/scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/scope" ] || fail "allowlisted strip-enabled replacement never ran the Git probe"
  assert_equals "$(printf 'local\t.project-hooks\ncommand\t%s' "$hooks")" \
    "$(cat "$dir/scope")" "allowlisted strip worker lost task hooks or inherited operator routing"
  assert_equals '' "$(cat "$dir/preserved")" "strip launch bypassed the environment filter"
  rm "$dir/pane-scope"
  "$real_tmux" -S "$socket" send-keys -t "$endpoint" \
    "git config --show-scope --get-all core.hooksPath > '$dir/pane-scope.tmp'; git config --get-all fixture.preserved > '$dir/pane-preserved'; mv '$dir/pane-scope.tmp' '$dir/pane-scope'" Enter
  for n in $(seq 1 100); do
    [ ! -f "$dir/pane-scope" ] || break
    sleep 0.1
  done
  [ -f "$dir/pane-scope" ] || fail "strip-enabled persistent pane never ran the Git probe"
  assert_equals "$(printf 'local\t.project-hooks\ncommand\t%s\ncommand\t%s' "$home/state/other.git-hooks" "$hooks")" \
    "$(cat "$dir/pane-scope")" "allowlisted strip launch lost pane routing or accumulated generated entries"
  assert_equals operator "$(cat "$dir/pane-preserved")" "allowlisted strip launch lost pane Git configuration"
  "$real_tmux" -S "$socket" kill-server
  rm -rf "/tmp/fm-$id" "/tmp/fm-$id+"*
  trap fm_test_cleanup EXIT
  pass "supported same-task $shell_name tmux relaunch reconciles generated hooks and preserves operator configuration"
}

test_cursor_trailer_does_not_reach_the_commit_object
test_human_coauthor_is_kept
test_human_at_a_vendor_domain_is_kept
test_hook_manager_cannot_displace_the_strip
test_reinstall_replaces_a_read_only_install
test_previous_commit_msg_hook_still_runs
test_relative_project_hookspath_still_runs
test_inherited_hookspath_env_does_not_decide_the_chain
test_project_hook_generated_after_install_still_runs
test_pane_hookspath_does_not_reroute_another_repository
test_repository_pre_push_runs_on_every_override_channel
test_git_c_override_still_strips_and_chains_commit_hooks
test_strip_msgfile_alone_does_not_rewrite_author_fields
test_relaunch_reconciles_only_its_generated_hooks

echo "# all fm-git-strip-ai-trailers tests passed"

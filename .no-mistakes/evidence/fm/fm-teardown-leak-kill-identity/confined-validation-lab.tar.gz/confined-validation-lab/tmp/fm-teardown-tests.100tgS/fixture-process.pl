sub fixture_birth {
  my ($pid) = @_;
  if (open my $stat, "<", "/proc/$pid/stat") {
    my $line = <$stat>;
    close $stat;
    $line =~ s/.*\)\s*//;
    my @fields = split /\s+/, $line;
    die "missing birth identity" unless @fields >= 20;
    return "starttime=$fields[19]";
  }
  local $ENV{LC_ALL} = "C";
  open my $ps, "-|", $ENV{REAL_PS_FOR_TEST}, "-p", $pid, "-o", "lstart=" or die "ps";
  my $start = <$ps>;
  close $ps or die "ps failed";
  defined $start or die "missing birth identity";
  $start =~ s/^\s+|\s+$//g;
  length $start or die "empty birth identity";
  return "lstart=$start";
}
sub fixture_track {
  my ($pid) = @_;
  my $birth = fixture_birth($pid);
  my $record = "$ENV{TEARDOWN_FIXTURE_PROCESSES}/$pid";
  open my $fh, ">", "$record.$$" or die "register fixture";
  print {$fh} "KILL\t$birth\n";
  close $fh or die "close fixture registration";
  rename "$record.$$", $record or die "publish fixture registration";
  return $birth;
}
1;
